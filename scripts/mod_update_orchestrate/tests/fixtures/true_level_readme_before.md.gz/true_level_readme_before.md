# Warhammer-40-000-DARKTIDE-Mods

> Rights boundary: this repository is a collection of independently sourced
> mods, translations, tools, archives, and references. No repository-wide
> license is granted. Each item keeps its original license and attribution
> requirements.
>
> See [LICENSE-SCOPE.md](LICENSE-SCOPE.md) and
> [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) before redistributing any
> item.
>

## Overview

**What it is:** A curated collection of mods, Traditional Chinese (Taiwan) translations, tools, archives, and references for Warhammer 40,000 DARKTIDE.

**Problem it solves:** It gives players one place to find the mods they need to get started and mods with Traditional Chinese (Taiwan) localization.

**Key features**

| Feature | What you’ll find |
| --- | --- |
| Mod catalog | Mods grouped by what they change, with links to their Nexus Mods pages. |
| Traditional Chinese (Taiwan) localization | Translations for selected mods. |
| Compatibility fixes | Privately maintained, unofficial fixes for AUPM and DPM, independent of the game developer and the original mod authors. |

**Quick start:** Open the [essential mods section](#基本必須安裝) and follow its Nexus Mods links for [Darktide Mod Loader](https://www.nexusmods.com/warhammer40kdarktide/mods/19?tab=description) and [Darktide Mod Framework](https://www.nexusmods.com/warhammer40kdarktide/mods/8).

**Licensing and attribution:** Each item retains its original license and attribution requirements. The collection has no repository-wide license. See [LICENSE-SCOPE.md](LICENSE-SCOPE.md) and [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

## 概覽

**這是什麼：** 精選的 Warhammer 40,000 DARKTIDE 模組、臺灣繁體中文翻譯、工具、封存檔與參考資料。

**解決的問題：** 玩家可以在同一處找到入門所需的模組，以及支援臺灣繁體中文的模組。

**主要特色**

| 特色 | 內容 |
| --- | --- |
| 模組目錄 | 依模組修改的內容分類，並附上 Nexus Mods 頁面連結。 |
| 臺灣繁體中文在地化 | 提供部分模組的翻譯。 |
| 相容性修正 | 收錄 AUPM 與 DPM 的非官方修正，由私人維護，獨立於遊戲開發商及模組原作者。 |

**快速開始：** 先查看[基本必須安裝](#基本必須安裝)，再透過該區段的 Nexus Mods 連結開啟 [Darktide Mod Loader](https://www.nexusmods.com/warhammer40kdarktide/mods/19?tab=description) 與 [Darktide Mod Framework](https://www.nexusmods.com/warhammer40kdarktide/mods/8) 的頁面。

**授權與來源標示：** 各項內容保留原有授權及來源標示要求。整個儲存庫沒有統一授權。請參閱 [LICENSE-SCOPE.md](LICENSE-SCOPE.md) 與 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。

---

## AUPM 私人修正（非官方）

本 Repository 收錄的 [AUPM](Warhammer%2040%2C000%20DARKTIDE/mods/AUPM/) 包含針對 Darktide 1.13.0／1.13.1 的私人相容性修正。此修正為本 Repository 私人維護的非官方版本，並非遊戲官方或 AUPM 原作者發布的更新。

修正內容包含新版技能冷卻介面相容性，以及任務計時尚未就緒時的錯誤處理。


## DPM 私人修正（非官方）

本 Repository 收錄的 [DPM](Warhammer%2040%2C000%20DARKTIDE/mods/DPM/) 包含針對 Darktide 1.13.1 的私人修正，並非遊戲官方或 DPM 原作者發布的更新。修正移除關閉介面時重建整個 HUD 的行為、補齊敵人血量資料清理、減少攻擊回呼中的重複查詢，並將 HUD 文字的正常格式化頻率限制在每秒最多 10 次；傷害事件仍逐次處理。

# 基本必須安裝

### [Darktide Mod Loader](https://www.nexusmods.com/warhammer40kdarktide/mods/19?tab=description)
    MOD載入器 - 使用MOD必備
- MOD 網站最後更新日期：待手動補（Nexus 公開頁面回傳 HTTP 403）
- MOD 版本：Version 26.06.24
- MOD 檔案名稱：Darktide Mod Loader 19 26.06.24 2026-06-24T06-07Z ndQ1md9gG
- 手動維護最後下載日期：2026-11-25

### [Darktide Mod Framework](https://www.nexusmods.com/warhammer40kdarktide/mods/8)
    MOD框架 - 想要使用MOD必備，此MOD才能夠讓你開始加入其他的MOD
- MOD 網站最後更新日期：待手動補（Nexus 公開頁面回傳 HTTP 403）
- MOD 版本：Version 26.10.22
- MOD 檔案名稱：Darktide Mod Framework 8 26.10.22 2026-10-23T02-11Z FQPKZQIuu.zip
- 手動維護最後下載日期：2026-11-25
---
# 遊戲體驗改善

### [What The Localization](https://www.nexusmods.com/warhammer40kdarktide/mods/163)
    翻譯修正器，
- MOD 網站最後更新日期：Last updated 08 July 2025, 1:59AM
- MOD 版本：Version 1.2.3
- MOD 檔案名稱：WhatTheLocalization-163-1-2-3-1751911304
- 手動維護最後下載日期：2025-07-09

### [Scoreboard](https://www.nexusmods.com/warhammer40kdarktide/mods/22)
    UI改善
- MOD 網站最後更新日期：Last updated 02 May 2026, 1:49AM
- MOD 版本：2.5
- MOD 檔案名稱：Scoreboard-22-2-5-1777657786
- 手動維護最後下載日期：2025-05-17

### [Power DI](https://www.nexusmods.com/warhammer40kdarktide/mods/281)
    進階記分板
- MOD 網站最後更新日期：Last updated 23 March 2026, 12:43AM
- MOD 版本：Version 1.1.19
- MOD 檔案名稱：Power_DI_1.1.19.zip-281-v1-1-19-1774197819
- 手動維護最後下載日期：2026-03-29

### [Skitarius](https://www.nexusmods.com/warhammer40kdarktide/mods/510)
    顱骨支援
- MOD 網站最後更新日期：2026-10-02T16:41:57Z（Nexus API 原文；Asia/Taipei：2026-10-03 00:41:57）
- MOD 版本：2.2.7
- MOD 檔案名稱：Skitarius 2.2.7 510 2.2.7 2026-10-02T16-41Z L8cAq8xlI.zip
- 手動維護最後下載日期：2026-10-03

### [Auto Loot](https://www.nexusmods.com/warhammer40kdarktide/mods/375)
    自動開啟箱子並撿取物品
- MOD 網站最後更新日期：Last updated 19 March 2026, 1:04AM
- MOD 版本：1.1.0
- MOD 檔案名稱：AutoLoot-375-1-1-0-1773853450
- 手動維護最後下載日期：2026-03-29

### [Healthbars](https://www.nexusmods.com/warhammer40kdarktide/mods/16)
    UI改善
- MOD 網站最後更新日期：Last updated 29 September 2026, 11:49PM
- MOD 版本：26.09.29
- MOD 檔案名稱：Healthbars 16 26.09.29 2026-09-29T15-49Z JvbS2v8s1.zip
- 手動維護最後下載日期：2026-09-30
- GitHub :
- Source=>  https://github.com/danreeves/darktide-mods
- Fork  =>  https://github.com/SyuanTsai/Darktide-Mods-Danreeves

### [IME Enable](https://www.nexusmods.com/warhammer40kdarktide/mods/167)
    啟用Windows輸入法 - 適用於中日韓等語言的玩家
- MOD 網站最後更新日期：Last updated 10 July 2026, 2:31AM
- MOD 版本：Version 1.2.0
- MOD 檔案名稱：IME_Enable 167 1.2.0 2026-07-09T18-31Z Z1K0I1f3D.zip
- 手動維護最後下載日期：2026-08-18

### [True Level](https://www.nexusmods.com/warhammer40kdarktide/mods/156)
    真實等級 - 顯示真正的等級
- MOD 網站最後更新日期：Last updated 17 August 2026, 4:20PM（目前瀏覽器顯示；UTC：2026-08-17T08:20:57Z；Asia/Taipei：2026-08-17 16:20:57；僅為 Nexus 上游正式版頁面資訊）
- MOD 版本：1.11.0（LucLeto 社群公開測試版；Nexus 正式版：1.10.3）
- MOD 檔案名稱：true_level.zip
- 手動維護最後下載日期：2026-10-07
- 來源類型：LucLeto 發布的 True Level 1.11.0 社群公開測試版；版本號與 ZIP 內 info.json 一致。
- 社群來源：[Nexus True Level 1.11.0 公開測試貼文](https://www.nexusmods.com/warhammer40kdarktide/mods/156?tab=posts#comment-176898600)
- 社群程式來源：[LucLeto/zombine04-darktide-mods](https://github.com/LucLeto/zombine04-darktide-mods/tree/f2a7b33848bbe46ff16baca4560ee808ee31ca33/true_level)；分支 `integration/true-level-havoc`；固定提交 `f2a7b33848bbe46ff16baca4560ee808ee31ca33`。
- 來源欄位說明：Nexus 欄位僅記錄上游正式版參考；本次 ZIP 來自社群 GitHub fork，Main file ID 與 Main file uploaded at UTC 均不適用，記為 not-applicable。
- GitHub（原作者上游與個人 fork）:
- Source=>  https://github.com/zombine04/darktide-mods
- Fork  =>  https://github.com/SyuanTsai/darktide-mods

### [Who Are You - Display account names](https://www.nexusmods.com/warhammer40kdarktide/mods/127)
    你是誰 - 顯示你Steam或者Xbox的帳號名稱
- MOD 網站最後更新日期：Last updated 03 December 2025, 3:15AM
- MOD 版本：Version 3.7.4
- MOD 檔案名稱：Who Are You-127-3-7-4-1764702919
- 手動維護最後下載日期：2025-12-06
- GitHub :
- Source=>  https://github.com/zombine04/darktide-mods
- Fork  =>  https://github.com/SyuanTsai/darktide-mods

### [MultiBind](https://www.nexusmods.com/warhammer40kdarktide/mods/337)
    多重綁定 - 讓你可以額外綁定按鍵
- MOD 網站最後更新日期：Last updated 09 July 202410:46AM
- MOD 版本：未提供
- MOD 檔案名稱：MultiBind.zip-337-V1-0-1720518374
- 手動維護最後下載日期：2025-02-09

### [More Characters and Loadouts](https://www.nexusmods.com/warhammer40kdarktide/mods/209)
    新增更多角色與天賦頁面
- MOD 網站最後更新日期：Last updated 15 September 2023 2:41AM
- MOD 版本：1.0.0
- MOD 檔案名稱：More Characters and Loadouts-209-1-0-0-1694742033
- 手動維護最後下載日期：2025-02-09

### [Psych Ward](https://www.nexusmods.com/warhammer40kdarktide/mods/89)
    在角色畫面快速開始
- MOD 網站最後更新日期：Last updated 14 April 2026, 2:19PM
- MOD 版本：1.7.1
- MOD 檔案名稱：Psych Ward-89-1-7-1-1776147547
- 手動維護最後下載日期：2026-05-17

### [Decode Helper](https://www.nexusmods.com/warhammer40kdarktide/mods/252)
    解碼助手 - 在解碼時顯示即將出現的目標符號。
- MOD 網站最後更新日期：Last updated 01 December 20233:14PM
- MOD 版本：1.1.0
- MOD 檔案名稱：Decode_Helper-252-1-1-1701443693
- 手動維護最後下載日期：2025-02-09

### [Decode Minigame Solver](https://www.nexusmods.com/warhammer40kdarktide/mods/426)
    自動解碼器
- MOD 網站最後更新日期：Last updated 17 December 2025, 8:51PM
- MOD 版本：1.2.2
- MOD 檔案名稱：DecodeMinigameSolver-426-1-2-2-1765975915
- 手動維護最後下載日期：2025-12-19

### [Train Solver](https://www.nexusmods.com/warhammer40kdarktide/mods/420)
    火車自動解碼器
- MOD 網站最後更新日期：Last updated 15 November 20249:39PM
- MOD 版本：1.1.0
- MOD 檔案名稱：TrainSolver.zip-420-V1-1-1731706748
- 手動維護最後下載日期：2025-02-09

### [Tree Helper](https://www.nexusmods.com/warhammer40kdarktide/mods/369)
    毒樹顯碼器
- MOD 網站最後更新日期：Last updated 01 October 2024 9:59PM
- MOD 版本：1.0.0
- MOD 檔案名稱：Tree_Helper-369-1-0-0-1727816343
- 手動維護最後下載日期：2025-02-09

### [Scan Helper](https://www.nexusmods.com/warhammer40kdarktide/mods/657)
    掃描助手
    [Old Scan Helper](https://www.nexusmods.com/warhammer40kdarktide/mods/352)
- MOD 網站最後更新日期：Last updated 23 July 2026, 6:00PM
- MOD 版本：1
- MOD 檔案名稱：ScanHelper 657 1 2026-07-23T18-00Z 4SVrcSAmj.zip
- 手動維護最後下載日期：2026-08-25

### [Show Crit Chance](https://www.nexusmods.com/warhammer40kdarktide/mods/279)
    顯示爆擊率 - 顯示當前爆擊率
- MOD 網站最後更新日期：Last updated 16 February 2025 1:51PM
- MOD 版本：1.1.0
- MOD 檔案名稱：show_crit_chance_v110-279-1-1-0-1739713916
- 手動維護最後下載日期：2025-02-18

### [Debuff Indicator](https://www.nexusmods.com/warhammer40kdarktide/mods/137)
    效果顯示
- MOD 網站最後更新日期：Last updated 17 December 2025, 10:37AM
- MOD 版本：1.7.4
- MOD 檔案名稱：Debuff Indicator-137-1-7-4-1765939029
- 手動維護最後下載日期：2025-12-19
- GitHub :
- Source=>  https://github.com/zombine04/darktide-mods
- Fork  =>  https://github.com/SyuanTsai/darktide-mods

### [Super Impact](https://www.nexusmods.com/warhammer40kdarktide/mods/319)
    超級衝擊 - 可以避免場地上一堆屍體擋住視線，但是會吃GPU
- MOD 網站最後更新日期：Last updated 19 June 202411:31PM
- MOD 版本：1.1
- MOD 檔案名稱：SuperImpact.zip-319-V1-1-1718836296
- 手動維護最後下載日期：2025-02-09

### [Stimms Pickup Icon](https://www.nexusmods.com/warhammer40kdarktide/mods/265)
    強化針顯示改善，讓你可以清楚知道隊友目前的針是甚麼
- MOD 網站最後更新日期：Last updated 07 December 2025, 1:30AM
- MOD 版本：1.4.0
- MOD 檔案名稱：StimmsPickupIcon-265-1-4-0-1765042230
- 手動維護最後下載日期：2025-12-07

### [Killfeed Improvements](https://www.nexusmods.com/warhammer40kdarktide/mods/70)
    擊殺名稱顯示改進
- MOD 網站最後更新日期：Last updated 05 August 2026, 2:36PM
- MOD 版本：26.08.05
- MOD 檔案名稱：KillfeedImprovements 70 26.08.05 2026-08-05T06-36Z vNTD9NbBl.zip
- 手動維護最後下載日期：2026-08-18

### [Gas Outline](https://www.nexusmods.com/warhammer40kdarktide/mods/398)
    瓦斯透明化 - 避免瓦斯導致你看不到隊友
- MOD 網站最後更新日期：Last updated 26 October 2024 9:35AM
- MOD 版本：1.0
- MOD 檔案名稱：GasOutline.zip-398-V1-0-1729931327
- 手動維護最後下載日期：2025-02-10

### [Loadout Monitor](https://www.nexusmods.com/warhammer40kdarktide/mods/160)
    載入中顯示隊友武器
- MOD 網站最後更新日期：Last updated 08 August 2026, 6:04PM
- MOD 版本：1.9.4
- MOD 檔案名稱：LoadoutMonitor 160 1.9.4 2026-08-08T10-03Z vNTD9Nbji.rar
- 手動維護最後下載日期：2026-08-18

### [Quick Look Card](https://www.nexusmods.com/warhammer40kdarktide/mods/142)
    快速資訊卡 可以快速取得武器的五維
- MOD 網站最後更新日期：Last updated 15 August 2025, 11:44PM
- MOD 版本：1.8.5
- MOD 檔案名稱：QuickLookCard-142-1-8-5-1755272684
- 手動維護最後下載日期：2025-09-30

### [Markers Improved All-in-One](https://www.nexusmods.com/warhammer40kdarktide/mods/447)
    標記一體化 整合包
- MOD 網站最後更新日期：2026-10-03T22:49:22Z（Nexus API 原文；Asia/Taipei：2026-10-04 06:49:22）
- MOD 版本：2.15.8
- MOD 檔案名稱：Markers Improved All-in-One 447 2.15.8 2026-10-03T22-49Z bTkWSTwFC.zip
- 手動維護最後下載日期：2026-10-04

### [Danger Zone](https://www.nexusmods.com/warhammer40kdarktide/mods/440)
    危險區域 - 顯示危險的範圍 爆桶、惡魔宿主...等
- MOD 網站最後更新日期：Last updated 27 December 2024 2:53AM
- MOD 版本：1.1.1
- MOD 檔案名稱：danger_zone-440-1-1-1-1735267980
- 手動維護最後下載日期：2025-02-11

### [Numeric UI](https://www.nexusmods.com/warhammer40kdarktide/mods/14)
    UI改善
- MOD 網站最後更新日期：Last updated 05 October 2026, 6:36PM（Nexus 頁面原文；UTC：2026-10-05T18:36:13Z；Asia/Taipei：2026-10-06 02:36:13）
- MOD 版本：26.10.05
- MOD 檔案名稱：NumericUI 14 26.10.05 2026-10-05T18-36Z ndQ1mdFpc.zip
- 手動維護最後下載日期：2026-10-06

### [Spidey Sense](https://www.nexusmods.com/warhammer40kdarktide/mods/268)
    蜘蛛感應 - 畫面顯示特定敵人位置
- MOD 網站最後更新日期：2026-08-23T16:50:12.0000000+00:00
- MOD 版本：7.9.0
- MOD 檔案名稱：Spidey Sense 7.9.0 268 7.9.0 2026-08-23T16-50Z 95Dkb5S3s.zip
- 手動維護最後下載日期：2026-09-02
- GitHub :
- Source=>  https://github.com/Wobin/SpideySense
- Fork  =>  https://github.com/SyuanTsai/Darktide-Mod-SpideySense

### [Enhanced Descriptions](https://www.nexusmods.com/warhammer40kdarktide/mods/210)
    描述改善
- MOD 網站最後更新日期：Last updated 18 July 2026, 2:02AM
- MOD 版本：6.0.0b
- MOD 檔案名稱：Enhanced Descriptions 210 6.0.0b 2026-07-17T18-02Z YFIfRFOFf.zip
- 手動維護最後下載日期：2026-08-29
- GitHub :
- Source=>  https://github.com/xsSplater/Darktide_Enhanced_Descriptions_BETA
- Fork  =>  https://github.com/SyuanTsai/Warhammer-40-000-DARKTIDE-Enhanced_Descriptions

### [Emperor's Guidance](https://www.nexusmods.com/warhammer40kdarktide/mods/468)
    靈能捏頭過濾器 - 能夠依照你要的順序捏頭
- MOD 網站最後更新日期：Last updated 27 September 2025, 11:21PM
- MOD 版本：1.2.8
- MOD 檔案名稱：Emperor's Guidance 1.2.7-468-1-2-7-1751131867
- 手動維護最後下載日期：2025-10-01

### [Remember Server Location](https://www.nexusmods.com/warhammer40kdarktide/mods/308)
    能夠固定預設的伺服器避免都是香港
- MOD 網站最後更新日期：Last updated 02 December 2025, 6:15AM
- MOD 版本：1.1.6
- MOD 檔案名稱：RememberServerLocation-308-1-1-6-1764627354
- 手動維護最後下載日期：2025-12-06
- GitHub :
- Source=>  https://github.com/deluxghost/darktide-mods
- Fork  =>  https://github.com/SyuanTsai/darktide-mods-1

### [Default To Highest Blessing Tier](https://www.nexusmods.com/warhammer40kdarktide/mods/364)
    預設天賦在第四層，避免沒注意到用了第一層天賦
- MOD 網站最後更新日期：Last updated 29 January 2025 4:18AM
- MOD 版本：1.0.2
- MOD 檔案名稱：DefaultToHighestBlessingTier-364-1-0-2-1738124336
- 手動維護最後下載日期：2025-02-23

### [Buy Until Rating](https://www.nexusmods.com/warhammer40kdarktide/mods/100)
    自動購買你要的武器(五維)
- MOD 網站最後更新日期：Last updated 27 January 2025 10:00PM
- MOD 版本：2.3.1
- MOD 檔案名稱：Buy Until Rating-100-2-3-1-1738015238
- 手動維護最後下載日期：2025-02-23

### [Character Screen Contracts (aka Better Melk)](https://www.nexusmods.com/warhammer40kdarktide/mods/71)
    角色大廳快速顯示週任進度
- MOD 網站最後更新日期：Last updated 22 July 2025, 2:15PM
- MOD 版本：1.11
- MOD 檔案名稱：BetterMelk-71-1-13-1753164937
- 手動維護最後下載日期：2025-07-23

### [Chat Block](https://www.nexusmods.com/warhammer40kdarktide/mods/68)
    2對話時自動防禦
- MOD 網站最後更新日期：Last updated 30 September 2026, 6:27AM
- MOD 版本：26.09.30
- MOD 檔案名稱：ChatBlock 68 26.09.30 2026-09-29T22-27Z 5gEeTgDDi.zip
- 手動維護最後下載日期：2026-09-30

### [Inspect from Social](https://www.nexusmods.com/warhammer40kdarktide/mods/254)
    查看玩家天賦裝備
- MOD 網站最後更新日期：Last updated 30 March 2025 3:58PM
- MOD 版本：1.0.5
- MOD 檔案名稱：Inspect from Social-254-1-0-5-1743350299
- 手動維護最後下載日期：2025-03-31

### [Inspect from Party Finder](https://www.nexusmods.com/warhammer40kdarktide/mods/455)
    組隊大廳查看玩家天賦裝備
    
- MOD 網站最後更新日期：Last updated 07 December 2025, 1:29PM
- MOD 版本：1.0.2
- MOD 檔案名稱：Inspect from Party Finder-455-1-0-2-1735149372
- 手動維護最後下載日期：2025-12-07

### [Player Outlines](https://www.nexusmods.com/warhammer40kdarktide/mods/39)
    顯示玩家框，讓你知道隊友的位置在哪。
- MOD 網站最後更新日期：Last updated 30 May 2023 5:17PM
- MOD 版本：1.2.2
- MOD 檔案名稱：PlayerOutlines-39-1-2-2-1685463446
- 手動維護最後下載日期：2025-02-24

### [Name It - Rename Weapons and Curios](https://www.nexusmods.com/warhammer40kdarktide/mods/181)
    替武器、珍品命名。
- MOD 網站最後更新日期：Last updated 17 December 2025, 10:36AM
- MOD 版本：1.3.7
- MOD 檔案名稱：Name It-181-1-3-7-1765938961
- 手動維護最後下載日期：2025-12-09

### [LoadoutNames](https://www.nexusmods.com/warhammer40kdarktide/mods/286)
    替天賦命名。
- MOD 網站最後更新日期：2026-10-05T02:24:26Z（Nexus API 原文；Asia/Taipei：2026-10-05 10:24:26）
- MOD 版本：1.9
- MOD 檔案名稱：LoadoutNames 286 1.9 2026-10-05T02-24Z X0p3C0jFM.zip
- 手動維護最後下載日期：2026-10-05

### [Guarantee Ability Activation](https://www.nexusmods.com/warhammer40kdarktide/mods/336)
    防止取消大絕
- MOD 網站最後更新日期：Last updated 02 October 2026, 1:02AM
- MOD 版本：1.4.2
- MOD 檔案名稱：Guarantee Ability Activation 336 1.4.2 2026-10-01T17-02Z Z1K0I1fFq.zip
- 手動維護最後下載日期：2026-10-02

### [Custom HUD](https://www.nexusmods.com/warhammer40kdarktide/mods/10)
    客製化UI
```
    請先備份user_settings.config!
    預設位置: C:\Users\[your-user-name-here]\AppData\Roaming\Fatshark\Darktide
```    
- MOD 網站最後更新日期：Last updated 07 April 2026, 11:01PM
- MOD 版本：2.1.3
- MOD 檔案名稱：Custom HUD-10-2-1-3-1775574086
- 手動維護最後下載日期：2026-05-17

### [Keep Dodging](https://www.nexusmods.com/warhammer40kdarktide/mods/182)
    自動閃避(長按時自動閃避)
- MOD 網站最後更新日期：Last updated 03 December 2025, 3:02AM
- MOD 版本：1.1.3
- MOD 檔案名稱：Keep Dodging-182-1-1-3-1764702136
- 手動維護最後下載日期：2025-12-06
- GitHub :
- Source=>  https://github.com/zombine04/darktide-mods
- Fork  =>  https://github.com/SyuanTsai/darktide-mods

### [Perspectives Mod](https://www.nexusmods.com/warhammer40kdarktide/mods/111)
    第三人稱視角
- MOD 網站最後更新日期：Last updated 24 August 2026, 5:05AM
- MOD 版本：1.14
- MOD 檔案名稱：Perspectives 111 1.14 2026-08-23T21-05Z l24cL2qQv.zip
- 手動維護最後下載日期：2026-08-31

### [Improved Havoc Tags](https://www.nexusmods.com/warhammer40kdarktide/mods/500)
    浩劫詞條說明改善
- MOD 網站最後更新日期：Last updated 24 September 2025, 11:37AM
- MOD 版本：3.1
- MOD 檔案名稱：Improved Havoc Tags-500-2-3-1750873657
- 手動維護最後下載日期：2025-10-01

### [Ovenproof's Scoreboard Plugin - Community Patch](https://www.nexusmods.com/warhammer40kdarktide/mods/514)
    記分板排版工具
- 原版 MOD：[Ovenproof's Scoreboard Plugin](https://www.nexusmods.com/warhammer40kdarktide/mods/241)
- MOD 網站最後更新日期：Last updated 22 February 2024, 10:22AM
- MOD 版本：1.4.2
- Patch 網站最後更新日期：Last updated 01 October 2026, 12:52AM
- Patch 版本：1.14.1
- MOD 檔案名稱：OvenProof's Scoreboard Plugin - Community Patch 514 1.14.1 2026-09-30T16-52Z yonmho6gN.zip
- 手動維護最後下載日期：2026-10-01
- GitHub :
- Source=>  https://github.com/Backup158/DarktideOvenproofScoreboardPluginPatch
- Fork  =>  https://github.com/SyuanTsai/Darktide-Mods-OvenproofScoreboardPluginPatch

### [Scoreboard Explosive](https://www.nexusmods.com/warhammer40kdarktide/mods/113)
    爆桶爆炸
- MOD 網站最後更新日期：Last updated 02 December 2023, 1:33AM
- MOD 版本：1.1.3
- MOD 檔案名稱：ScoreboardExplosive-113-1-1-3-1701451982
- 手動維護最後下載日期：2025-07-05

### [Better Hud Info View](https://www.nexusmods.com/warhammer40kdarktide/mods/511)
    浩劫HUD資訊
- MOD 網站最後更新日期：Last updated 01 October 2026, 11:13PM
- MOD 版本：1.6
- MOD 檔案名稱：Better Hud Info View 511 1.6 2026-10-01T15-13Z q4A7x4GUb.zip
- 手動維護最後下載日期：2026-10-02

### [Recolor Boss Health Bars](https://www.nexusmods.com/warhammer40kdarktide/mods/314)
    重著色BOSS血條
- MOD 網站最後更新日期：2026-07-19T15:18:00.0000000+00:00
- MOD 版本：2.4
- MOD 檔案名稱：Recolor Boss Health Bars 314 2.4 2026-07-19T15-18Z L8cAq8xR5.zip
- 手動維護最後下載日期：2026-09-01
---
- 手動維護最後下載日期：2025-07-12

### [Red Weapons at Home](https://www.nexusmods.com/warhammer40kdarktide/mods/380)
    武器顏色顯示
- MOD 網站最後更新日期：Last updated 10 July 2025, 7:04PM
- MOD 版本：1.2.5
- MOD 檔案名稱：Red Weapons at Home-380-1-2-5-1752145450
- 手動維護最後下載日期：2025-07-12

### [AutoBlitz](https://www.nexusmods.com/warhammer40kdarktide/mods/480)
    自動手榴彈(一鍵投出、獒犬自爆)
- MOD 網站最後更新日期：Last updated 10 October 2026, 12:23AM
- MOD 版本：1.1.1
- MOD 檔案名稱：AutoBlitz 1.1.1 480 1.1.1 2026-10-09T16-23Z txMvExebC
- 手動維護最後下載日期：2026-11-25
- Google Drive

### [SpecialsTracker](https://www.nexusmods.com/warhammer40kdarktide/mods/274)
    顯示場上所有特感數量
- MOD 網站最後更新日期：2026-07-23T19:43:11.0000000+00:00
- MOD 版本：1.8
- MOD 檔案名稱：SpecialsTracker 274 1.8 2026-07-23T19-43Z txMvExeiL.zip
- 手動維護最後下載日期：2026-09-02

### [Display Ping (Latency)](https://www.nexusmods.com/warhammer40kdarktide/mods/460)
    顯示延遲
- MOD 網站最後更新日期：Last updated 14 April 2025, 3:47AM
- MOD 版本：1.5.1
- MOD 檔案名稱：DisplayPing-460-1-6-2-1744573670
- 手動維護最後下載日期：2025-07-23

### [Reconnect](https://www.nexusmods.com/warhammer40kdarktide/mods/132)
    
- MOD 網站最後更新日期：Last updated 18 August 2026, 2:33AM
- MOD 版本：1.3.0
- MOD 檔案名稱：Reconnect 132 1.3.0 2026-08-18T02-33Z UszQnsmqf.zip
- 手動維護最後下載日期：2026-08-22

### [Valkyrie Blitz-Ingress](https://www.nexusmods.com/warhammer40kdarktide/mods/544)
    省略開場任務介紹(浩劫斷線時加速回歸)
- MOD 網站最後更新日期：Last updated 01 April 2026, 9:12PM
- MOD 版本：0.4
- MOD 檔案名稱：Valkyrie Blitz-Ingress-544-0-4-1775048992
- 手動維護最後下載日期：2026-04-03

### [BornReady](https://www.nexusmods.com/warhammer40kdarktide/mods/96)
    預先載入
- MOD 網站最後更新日期：2026-10-05T02:24:26Z（Nexus API 原文；Asia/Taipei：2026-10-05 10:24:26）
- MOD 版本：1.8
- MOD 檔案名稱：BornReady 96 1.8 2026-10-05T02-24Z ke28WelNA.zip
- 手動維護最後下載日期：2026-10-05

### [MissionBrief](https://www.nexusmods.com/warhammer40kdarktide/mods/387)
    預先載入
- MOD 網站最後更新日期：Last updated 24 August 2026, 5:04AM
- MOD 版本：1.12
- MOD 檔案名稱：MissionBrief 387 1.12 2026-08-23T21-04Z 8bwV4bcyz.zip
- 手動維護最後下載日期：2026-08-30
### [InventoryStats](https://www.nexusmods.com/warhammer40kdarktide/mods/152)
    玩家Build資訊
- MOD 網站最後更新日期：Last updated 24 August 2026, 5:04AM
- MOD 版本：1.10
- MOD 檔案名稱：InventoryStats 152 1.10 2026-08-23T21-04Z 8bwV4bcyi.zip
- 手動維護最後下載日期：2026-08-30

### [Clear Smoke](https://www.nexusmods.com/warhammer40kdarktide/mods/517)
    煙霧輔助
- MOD 網站最後更新日期：Last updated 24 July 2026, 8:41PM
- MOD 版本：1.5
- MOD 檔案名稱：clear_smoke 517 1.5 2026-07-24T12-41Z AVBg7VNZu.zip
- 手動維護最後下載日期：2026-08-15
- Use Google driver.

### [Quick Level Mastery](https://www.nexusmods.com/warhammer40kdarktide/mods/395)
    自動升級裝備(含自動買)
- MOD 網站最後更新日期：Last updated 23 January 2026, 3:18AM
- MOD 版本：0.1.1
- MOD 檔案名稱：Quick Level Mastery-395-0-1-1-1769109536
- 手動維護最後下載日期：2026-03-21

### [I Wanna See](https://www.nexusmods.com/warhammer40kdarktide/mods/371)
    修改火焰特效的顯示方式
- MOD 網站最後更新日期：Last updated 30 July 2025, 11:25AM
- MOD 版本：1.1.2
- MOD 檔案名稱：I Wanna See-371-1-1-2-1753845943
- 手動維護最後下載日期：2025-12-28

### [VFX Swapper](https://www.nexusmods.com/warhammer40kdarktide/mods/678)
    修改特效的顯示方式
- MOD 網站最後更新日期：Last updated 02 October 2026, 4:01AM
- MOD 版本：1.3.1
- MOD 檔案名稱：Vfx Swapper 678 1.3.1 2026-10-01T20-01Z iYOupY30h.zip
- 手動維護最後下載日期：2026-10-02

### [CombatStats](https://www.nexusmods.com/warhammer40kdarktide/mods/661)
    記分板
- MOD 網站最後更新日期：Last updated 03 August 2026, 2:39PM
- MOD 版本：0.5.11
- MOD 檔案名稱：CombatStats 661 0.5.11 2026-08-03T06-39Z PhaYKh0Gw.zip
- 手動維護最後下載日期：2026-08-15

### [CharacterGrid](https://www.nexusmods.com/warhammer40kdarktide/mods/649)
    角色顯示
- MOD 網站最後更新日期：Last updated 26 December 2025, 6:30PM
- MOD 版本：1.0.1
- MOD 檔案名稱：CharacterGrid-649-1-0-1-1765318330
- 手動維護最後下載日期：2025-12-28

### [TeamKills](https://www.nexusmods.com/warhammer40kdarktide/mods/577)
    顯示隊伍擊殺資訊
- MOD 網站最後更新日期：Last updated 26 December 2025, 6:30PM
- MOD 版本：2.2.1
- MOD 檔案名稱：TeamKills-577-2-2-1-1767136133
- 手動維護最後下載日期：2026-01-01

### [BrokerAutoStim](https://www.nexusmods.com/warhammer40kdarktide/mods/655)
    在戰鬥中自動使用化學興奮劑，支援設定檔切換、取消動畫與戰鬥狀態檢查
- MOD 網站最後更新日期：Last updated 01 October 2026, 1:11AM
- MOD 版本：3.1
- MOD 檔案名稱：BrokerAutoStim 655 3.1 2026-09-30T17-11Z cwrBAw7dp.zip
- 手動維護最後下載日期：2026-10-01

### [TalentUI](https://www.nexusmods.com/warhammer40kdarktide/mods/683)
    天賦UI
- MOD 網站最後更新日期：Last updated 10 April 2026, 2:48AM（Nexus 頁面原文；UTC：2026-04-10T02:48:54Z；Asia/Taipei：2026-04-10 10:48:54；僅為上游正式版頁面資訊）
- MOD 版本：2026-10-07 Community Correction（社群修正識別；上游正式版：1.2.1）
- MOD 檔案名稱：TalentUI_fixes_plus.zip
- 手動維護最後下載日期：2026-10-07
- 來源類型：LucLeto 社群修正；ZIP 未提供作者發行版號，上述修正識別沿用本分支既有提交標記。
- 社群來源：[Nexus TalentUI 社群修正貼文](https://www.nexusmods.com/warhammer40kdarktide/mods/683?tab=posts)
- 社群程式來源：[LucLeto/rrmllnv-darktide-mods](https://github.com/LucLeto/rrmllnv-darktide-mods/tree/ec5a33ce5b4c8909feaf6523515b4b2ed178c661/TalentUI)；分支 `maintenance/talent-ui-fixes`；固定提交 `ec5a33ce5b4c8909feaf6523515b4b2ed178c661`。
- 來源欄位說明：Nexus 欄位僅記錄上游正式版參考；本次 ZIP 來自社群 GitHub fork，Main file ID 與 Main file uploaded at UTC 均不適用，因此記為 `not-applicable`。

### [Machine God's BeaconUI](https://www.nexusmods.com/warhammer40kdarktide/mods/684)
    地圖燈效控制
- MOD 網站最後更新日期：Last updated 14 July 2026, 8:10PM
- MOD 版本：2026.07.16
- MOD 檔案名稱：Machine Gods Beacon 684 2026.07.16 2026-07-14T12-10Z rlqxBlgxu.zip
- 手動維護最後下載日期：2026-08-19

### [VeilShield](https://www.nexusmods.com/warhammer40kdarktide/mods/637)
    盾牌透明化
- MOD 網站最後更新日期：Last updated 31 January 2026, 7:25PM
- MOD 版本：1.4
- MOD 檔案名稱：Machine God's Beacon-684-2026-01-26-1769450266
- 手動維護最後下載日期：2026-02-02

### [Modular Menu Buttons](https://www.nexusmods.com/warhammer40kdarktide/mods/166)
    快速選單
- MOD 網站最後更新日期：Last updated 23 March 2026, 4:49PM
- MOD 版本：1.2.9
- MOD 檔案名稱：Modular Menu Buttons-166-1-2-9-1774255754
- 手動維護最後下載日期：2026-03-29

### [Retain Selection](https://www.nexusmods.com/warhammer40kdarktide/mods/485)
    我的最愛功能(需確認是否需要保留)
- MOD 網站最後更新日期：Last updated 14 March 2025, 7:25PM
- MOD 版本：1.0
- MOD 檔案名稱：Retain Selection-485-1-0-1741951532
- 手動維護最後下載日期：2026-07-14

### [Show CJK Glyphs](https://www.nexusmods.com/warhammer40kdarktide/mods/149)
    顯示亞洲區域字型
- MOD 網站最後更新日期：Last updated 16 April 2025, 10:35PM
- MOD 版本：1.0.3
- MOD 檔案名稱：show_cjk_glyphs-149-2-0-2-1683521516
- 手動維護最後下載日期：2026-07-14

### [Simple Speed Meter](https://www.nexusmods.com/warhammer40kdarktide/mods/404)
    顯示移動速度(用於比較不同武器的移動)
- MOD 網站最後更新日期：Last updated 08 May 2023, 12:51PM
- MOD 版本：2.02
- MOD 檔案名稱：SimpleSpeedMeter-404-1-0-3-1744814116
- 手動維護最後下載日期：2026-07-14

### [Server ping](https://www.nexusmods.com/warhammer40kdarktide/mods/1221)
    顯示真實的服務器PING
- MOD 網站最後更新日期：Last updated 25 August 2026, 12:08AM
- MOD 版本：Version 1
- MOD 檔案名稱：ServerPing 1221 1 2026-08-24T16-06Z SDWlwDVLT
- 手動維護最後下載日期：2026-09-07

### [Havoc Peek](https://www.nexusmods.com/warhammer40kdarktide/mods/1228)
    浩劫(快速看野團資訊)
- MOD 網站最後更新日期：Last updated 26 August 2026, 9:05PM
- MOD 版本：Version 1
- MOD 檔案名稱：HavocPeek 1228 1 2026-08-26T13-05Z pRus3Ro4C
- 手動維護最後下載日期：2026-09-07

### [FpsDoctor_LuaMemoryCleaner](https://www.nexusmods.com/warhammer40kdarktide/mods/932)
    效能監控與記憶體清理
- MOD 網站最後更新日期：Last updated 23 August 2026, 11:33PM（Nexus 頁面顯示；UTC：2026-08-23T23:33:54Z；Asia/Taipei：2026-08-24 07:33:54）
- MOD 版本：9（Nexus Main file 版本；ZIP 內 FpsDoctor.mod 版本：1.6.5）
- MOD 檔案名稱：FpsDoctor(FreezeFixesMemOptionsNewDmfFix) 932 9 2026-08-23T23-33Z mz1PFzZKs.zip
- 手動維護最後下載日期：2026-10-07

### [Another Scoreboard](https://www.nexusmods.com/warhammer40kdarktide/mods/1203)
    新型記分板
- MOD 網站最後更新日期：Last updated 04 October 2026, 3:36AM
- MOD 版本：2.0.2
- MOD 檔案名稱：AnotherScoreboard（Nexus 公開頁面未提供完整檔名，待手動補）
- 手動維護最後下載日期：2026-10-07

---
# 遊戲內操作相關MOD

### [Talent Tree UX Improvements](https://www.nexusmods.com/warhammer40kdarktide/mods/216)
   技能修改助手 - 能夠讓你快速地更換天賦支線
- MOD 網站最後更新日期：Last updated 30 September 2026, 2:51AM
- MOD 版本：1.11
- MOD 檔案名稱：TalentRefundBelow 216 1.11 2026-09-29T18-51Z VWLqrWBBr.zip
- 手動維護最後下載日期：2026-09-30

### [Archivum Messelina](https://www.nexusmods.com/warhammer40kdarktide/mods/307)
    梅塞利納檔案館 - 改善苦修搜尋
- MOD 網站最後更新日期：Last updated 16 July 2026, 7:53PM
- MOD 版本：3.2
- MOD 檔案名稱：Archivum Messelina 3.2 307 3.2 2026-07-16T11-53Z oudzUuncp.zip
- 手動維護最後下載日期：2026-08-13

### [Many More Try](https://www.nexusmods.com/warhammer40kdarktide/mods/175)
    任務管理器 - 可以啟動最近3小時內的任何關卡
- MOD 網站最後更新日期：Last updated 29 September 2026, 8:30PM
- MOD 版本：Version 1.5.8
- MOD 檔案名稱：ManyMoreTry 175 1.5.8 2026-09-29T12-30Z ke28Welol
- 手動維護最後下載日期：2026-09-30
- GitHub :
- Source=>  https://github.com/deluxghost/darktide-mods
- Fork  =>  https://github.com/SyuanTsai/darktide-mods-1


### [Solo Play (Havoc Update)](https://www.nexusmods.com/warhammer40kdarktide/mods/176)
    單人遊戲 - 支援浩劫模式
- MOD 網站最後更新日期：2026-10-04T11:40:18Z（Nexus API 原文；Asia/Taipei：2026-10-04 19:40:18）
- MOD 版本：2.6.10
- MOD 檔案名稱：SoloPlay 176 2.6.10 2026-10-04T11-40Z Ci3ojiHbH.zip
- 手動維護最後下載日期：2026-10-04

### [KeepSwinging](https://www.nexusmods.com/warhammer40kdarktide/mods/88)
    自動輕擊
- MOD 網站最後更新日期：Last updated 24 August 2026, 5:05AM
- MOD 版本：1.13
- MOD 檔案名稱：KeepSwinging 88 1.13 2026-08-23T21-05Z iYOupY3AS.zip
- 手動維護最後下載日期：2026-08-30

### [TagKeys](https://www.nexusmods.com/warhammer40kdarktide/mods/79)
    使用快捷鍵做遊戲標記
- MOD 網站最後更新日期：Last updated 24 August 2026, 5:04AM
- MOD 版本：1.5
- MOD 檔案名稱：TagKeys 79 1.5 2026-08-23T21-04Z SDWlwDVU0.zip
- 手動維護最後下載日期：2026-08-30

### [Weapon Filter](https://www.nexusmods.com/warhammer40kdarktide/mods/373)
    武器過濾
- MOD 網站最後更新日期：Last updated 27 January 2025 8:11PM
- MOD 版本：1.0.3
- MOD 檔案名稱：Wea-373-1-0-3-1738008684
- 手動維護最後下載日期：2025-02-24

### [AFK](https://www.nexusmods.com/warhammer40kdarktide/mods/33)
    防止AFK
- MOD 網站最後更新日期：Last updated 05 April 2023 6:21AM
- MOD 版本：23.04.05
- MOD 檔案名稱：AFK-33-23-4-05-1680675716
- 手動維護最後下載日期：2025-04-05

### [Remember Difficulty](https://www.nexusmods.com/warhammer40kdarktide/mods/490)
    記住最後的的難度
- MOD 網站最後更新日期：Last updated 17 December 2025, 10:32AM
- MOD 版本：1.0.1
- MOD 檔案名稱：Remember Difficulty-490-1-0-1-1765938766
- 手動維護最後下載日期：2025-12-19

### [Share Talents](https://www.nexusmods.com/warhammer40kdarktide/mods/215)
    天賦分享
- MOD 網站最後更新日期：Last updated 02 December 2025, 6:17AM
- MOD 版本：1.2.1
- MOD 檔案名稱：ShareTalents-215-1-2-1-1764627463
- 手動維護最後下載日期：2025-12-06
- GitHub :
- Source=>  https://github.com/deluxghost/darktide-mods
- Fork  =>  https://github.com/SyuanTsai/darktide-mods-1

### [Auto Rations - Recover or Destroy](https://www.nexusmods.com/warhammer40kdarktide/mods/625)
    自動撿拾糧食(活動用)
- MOD 網站最後更新日期：Last updated 22 October 2025, 11:58PM
- MOD 版本：1.1
- MOD 檔案名稱：auto_rations-625-1-1-1761148704
- 手動維護最後下載日期：2025-12-06

### [Empower Until Limit](https://www.nexusmods.com/warhammer40kdarktide/mods/365)
    自動升級裝備
- MOD 網站最後更新日期：Last updated05 October 2024, 10:30AM
- MOD 版本：1.0.2
- MOD 檔案名稱：auto_rations-625-1-1-1761148704
- 手動維護最後下載日期：2025-12-08

### [StimmCountdown](https://www.nexusmods.com/warhammer40kdarktide/mods/653)
    巢都敗類興奮劑CD
- MOD 網站最後更新日期：Last updated 03 May 2026, 12:30AM
- MOD 版本：1.4.1
- MOD 檔案名稱：StimmCountdown-653-1-4-1-1777739403
- 手動維護最後下載日期：2026-05-17

### [Mauler Attack Indicator](https://www.nexusmods.com/warhammer40kdarktide/mods/638)
    顯示重錘兵過頂攻擊的黃色預警圈與紅色攻擊圈；攻擊遭踉蹌中斷時會撤除當次提示，並可設定常駐黃色圓環。
- MOD 網站最後更新日期：Last updated 20 March 2026, 9:14AM
- MOD 版本：1.0.1
- MOD 檔案名稱：Mauler Attack Indicator-638-1-0-1-1773969244
- 手動維護最後下載日期：2026-03-29
- 私人修正（非官方）：本儲存庫以原作者 1.0.1 版為基礎，加入踉蹌中斷撤圈與生命週期清理；這不是遊戲官方或 MOD 原作者發布的更新。

### [Crusher Attack Indicator](https://www.nexusmods.com/warhammer40kdarktide/mods/639)
    顯示碾壓者橫掃攻擊的黃色預警圈與紅色攻擊圈；攻擊遭踉蹌中斷時會撤除當次提示，並可設定常駐黃色圓環。
- MOD 網站最後更新日期：Last updated 20 March 2026, 9:10AM
- MOD 版本：1.0.1
- MOD 檔案名稱：Crusher Attack Indicator-639-1-0-1-1773969032
- 手動維護最後下載日期：2026-03-29
- 私人修正（非官方）：本儲存庫以原作者 1.0.1 版為基礎，加入踉蹌中斷撤圈與生命週期清理；這不是遊戲官方或 MOD 原作者發布的更新。

### [Creature Spawner](https://www.nexusmods.com/warhammer40kdarktide/mods/25)
    怪物生成器 - 靈能室可以選擇要生那些怪，並且產生特定波次訓練身法。
- MOD 網站最後更新日期：Last updated 26 July 2026, 4:04AM
- MOD 版本：26.07.25
- MOD 檔案名稱：Creature Spawner 25 26.07.25 2026-07-25T20-04Z IP0ifPXuX.zip
- 手動維護最後下載日期：2026-08-16

### [Radar](https://www.nexusmods.com/warhammer40kdarktide/mods/790)
    遠征模式的小地圖
- MOD 網站最後更新日期：2026-10-07T23:07:40Z（Nexus API；頁面顯示時間原文未取得）
- MOD 版本：3.1.0
- MOD 檔案名稱：Radar 790 3.1.0 2026-10-07T23-07Z AVBg7VNY3.zip
- 手動維護最後下載日期：2026-10-08（本機 ZIP 確認日期）

### [PlasmaBFG](https://www.nexusmods.com/warhammer40kdarktide/mods/834)
    電漿槍 優化
- MOD 網站最後更新日期：Last updated 05 May 2026, 6:56PM
- MOD 版本：1.0.9
- MOD 檔案名稱：PlasmaBFG-834-1-0-9-1777978588
- 手動維護最後下載日期：2026-05-17

### [SprintRelicHeavy](https://www.nexusmods.com/warhammer40kdarktide/mods/804)
    聖物劍操作強化
- MOD 網站最後更新日期：Last updated 04 April 2026, 4:35PM
- MOD 版本：1.0.2
- MOD 檔案名稱：SprintRelicHeavy-804-1-0-2-1775291723
- 手動維護最後下載日期：2026-05-17

### [Auto Mark](https://www.nexusmods.com/warhammer40kdarktide/mods/736)
    自動標記 (非狗哨)
- MOD 網站最後更新日期：Last updated 07 October 2026, 7:53PM（Nexus 頁面顯示；UTC：2026-10-07T19:53:42Z；Asia/Taipei：2026-10-08 03:53:42）
- MOD 版本：2.5.4
- MOD 檔案名稱：AutoMark 736 2.5.4 2026-10-07T19-53Z hUmF6UaSp.zip
- 手動維護最後下載日期：2026-10-08

### [ErrorTracker](https://www.nexusmods.com/warhammer40kdarktide/mods/824)
    錯誤追蹤
- MOD 網站最後更新日期：Last updated 13 April 2026, 2:22AM
- MOD 版本：1.1
- MOD 檔案名稱：ErrorTracker-824-1-1-1776018123
- 手動維護最後下載日期：2026-07-06

### [NoBrainer](https://www.nexusmods.com/warhammer40kdarktide/mods/896)
    最新的小遊戲助手
- MOD 網站最後更新日期：Last updated 29 August 2026, 3:13 am
- MOD 版本：3.1.4
- MOD 檔案名稱：NoBrainer 896 3.1.4 2026-08-28T19-13Z 3OsdoOUuY
- 手動維護最後下載日期：2026-09-02


### [Simple Assets](https://www.nexusmods.com/warhammer40kdarktide/mods/1008)
    Spidey Sense 的依賴MOD
- MOD 網站最後更新日期：Last updated 26 August 2026, 4:39AM
- MOD 版本：2.0.0
- MOD 檔案名稱：SimpleAssets 1008 2.0.0 2026-08-25T20-39Z ufCjsfdVf.zip
- 手動維護最後下載日期：2026-10-02

### [Field_Awareness](https://www.nexusmods.com/warhammer40kdarktide/mods/1359)
    顯示特定怪物的輪廓與攻擊區域(可視範圍內)
- MOD 網站最後更新日期：Last updated 07 October 2026, 6:18PM（Nexus 頁面顯示；UTC：2026-10-07T18:18:49Z；Asia/Taipei：2026-10-08 02:18:49）
- MOD 版本：1.5.1（Nexus 頁面與 ZIP 內版本；Nexus Main file 版本欄位：1）
- MOD 檔案名稱：Field Awareness V1.5.1 Enemies Outlined And More 1359 1 2026-10-07T18-18Z Z1K0I1fL0.zip
- 手動維護最後下載日期：2026-10-08

### [Uptime 2 - Buff Data and Scoreboard](https://www.nexusmods.com/warhammer40kdarktide/mods/898)
    觀察天賦的運作狀況
- MOD 網站最後更新日期：Last updated 01 October 2026, 8:49PM（Nexus 頁面原文；UTC：2026-10-01T20:49:05Z；Asia/Taipei：2026-10-02 04:49:05）
- MOD 版本：2.15
- MOD 檔案名稱：Uptime (5) 898 2.15 2026-10-01T20-49Z l24cL2qWj.zip
- 手動維護最後下載日期：2026-10-06

# 移除的MOD

### [Curios Auspex](https://www.nexusmods.com/warhammer40kdarktide/mods/1226)
    飾品助手
- MOD 網站最後更新日期：Last updated 31 August 2026, 3:54AM
- MOD 版本：2.11
- MOD 檔案名稱：CuriosAuspex v2.1.1 1226 2.1.1 2026-08-30T19-54Z H3Uny3hlt
- 手動維護最後下載日期：2026-09-07
- 移除原因：目前與Character Screen Contracts (aka Better Melk)嚴重衝突

### [FullAuto](https://www.nexusmods.com/warhammer40kdarktide/mods/87)
    自動開火，只要按住就會一直開火
- MOD 網站最後更新日期：Last updated 07 December 2023 3:46AM
- MOD 版本：1.15
- MOD 檔案名稱：FullAuto-87-1-15-1701920784
- 手動維護最後下載日期：2025-03-09
- 移除原因：使用機械神教MOD替代。

### [Do I Know You](https://www.nexusmods.com/warhammer40kdarktide/mods/488)
    顯示移動速度(計算方式很難凸顯出真的想跟他玩的玩家)
    單純看勝敗場，但是也有贏了玩得很悶的情境。
- MOD 網站最後更新日期：Last updated 21 March 2025 2:43PM
- MOD 版本：1.0.3
- MOD 檔案名稱：Do I Know You 1.0.3.zip-488-1-0-3-1743019163
- 手動維護最後下載日期：2025-03-31
- 移除原因：只計算勝敗場，沒有計算其他數據。

### JishuJun
    團隊計分
- MOD 網站最後更新日期：NA
- MOD 版本：NA
- MOD 檔案名稱：NA
- 手動維護最後下載日期：NA
- 移除原因：使用新版KPM替代。

### [Hybrid Sprint](https://www.nexusmods.com/warhammer40kdarktide/mods/342?tab=description)
    混合衝刺 - 能夠解放雙手不需要一直衝刺
- MOD 網站最後更新日期：Last updated 17 October 20241:44PM
- MOD 版本：Version 1.3.1
- MOD 檔案名稱：Hybrid Sprint-342-1-3-1-1729169092
- 手動維護最後下載日期：2025-02-09
- 移除原因：個人操作問題不會去使用。

### [Transparent Shield (Ogryn)](https://www.nexusmods.com/warhammer40kdarktide/mods/439)
    歐格林盾牌半透明畫
- MOD 網站最後更新日期：Last updated 30 November 2024 7:37PM
- MOD 版本：1.2.0
- MOD 檔案名稱：TransparentShield-439-1-2-0-1732995433
- 手動維護最後下載日期：2025-02-09
- 移除原因：終止支援。

### [DarkCache](https://www.nexusmods.com/warhammer40kdarktide/mods/114)
    預先載入
- MOD 網站最後更新日期：Last updated 29 June 2023, 6:49PM
- MOD 版本：1.4
- MOD 檔案名稱：DarkCache-114-1-4-1688035784
- 手動維護最後下載日期：2025-07-23
- 移除原因：久未更新會有錯誤。

### [Unga Bunga](https://www.nexusmods.com/warhammer40kdarktide/mods/476)
    自動重擊
- MOD 網站最後更新日期：Last updated 01 April 2025 12:49PM
- MOD 版本：1.4.1
- MOD 檔案名稱：UngaBunga 1.4.1-476-1-4-1-1743511746
- 手動維護最後下載日期：2025-04-01
- 移除原因：機械神教取代

### [PlasmaGunLagFix](https://www.nexusmods.com/warhammer40kdarktide/mods/666)
    修正當前版本電漿槍會Lag的問題
- MOD 網站最後更新日期：Last updated 13 December 2025, 12:51PM
- MOD 版本：1.01
- MOD 檔案名稱：Quick Level Mastery-395-0-1-0-1730554189
- 手動維護最後下載日期：2025-12-13
- 移除原因：官方已修復

### [AutoQuell]
    自動平息
- MOD 網站最後更新日期：
- MOD 版本：
- MOD 檔案名稱：
- 手動維護最後下載日期
- 移除原因：總會在你不想要冷卻的時候自己冷卻

### [Teammate Health Bars](https://www.nexusmods.com/warhammer40kdarktide/mods/560)
    隊友血條顯示
- MOD 網站最後更新日期：Last updated 09 July 2025, 4:26AM
- MOD 版本：2.4
- MOD 檔案名稱：Team health bars-560-2-4-1752006409
- 手動維護最後下載日期：2025-07-12
- 移除原因：知道隊友血條後能做的是有限，反而會扣招。

### [AutoTag](https://www.nexusmods.com/warhammer40kdarktide/mods/374)
    自動標記 - 只要準心有對到菁英以上都會自動標記
- MOD 網站最後更新日期：Last updated 24 June 2025, 12:16PM
- MOD 版本：1.7
- MOD 檔案名稱：AutoTag.zip-374-v-1-7-1750738584
- 手動維護最後下載日期：2025-06-24
- 移除原因：與狗哨(DogWhistle)功能重複

### [RickAndMortis](https://www.nexusmods.com/warhammer40kdarktide/mods/491)
    靈能室測試死神試煉的技能
- MOD 網站最後更新日期：Last updated 30 March 2025 4:49AM
- MOD 版本：0.55
- MOD 檔案名稱：RickAndMortis.zip-491-0-55-1743310031
- 手動維護最後下載日期：2025-04-03
- 移除原因：開發者已經停止維護，啟用功能會導致遊戲崩潰。

### [Alternate Grenade Icons](https://www.nexusmods.com/warhammer40kdarktide/mods/322)
    替代手雷圖案 - 讓你可以快速辨識隊友帶甚麼手雷
- MOD 網站最後更新日期：Last updated 08 June 2024 8:30PM
- MOD 版本：1.0
- MOD 檔案名稱：AlternateGrenadeIcons-322-1-0-1717874669
- 手動維護最後下載日期：2025-02-10
- 移除原因：TalentUI取代此MOD

### [HoldFire](https://www.nexusmods.com/warhammer40kdarktide/mods/797)
    火力管控 - 防止無效開火
- MOD 網站最後更新日期：Last updated 07 May 2026, 3:08PM
- MOD 版本：1.1.4
- MOD 檔案名稱：HoldFire-797-1-1-4-1778137707
- 手動維護最後下載日期：2026-05-17
- 移除原因：作者停止維護，且某些情境下對電將槍造成阻礙。

### [MemoryLeakFix](https://www.nexusmods.com/warhammer40kdarktide/mods/406)
    減緩記憶體崩潰
- MOD 網站最後更新日期：Last updated 31 October 2024, 7:25PM
- MOD 版本：1.1.2
- MOD 檔案名稱：MemLeakFix-406-1-1-2-1730373955
- 手動維護最後下載日期：2025-12-28
- 移除原因：SMOG Cleaner取代此功能。

### [AuspexHelper](https://www.nexusmods.com/warhammer40kdarktide/mods/757)
    遠征模式的小弟圖
- MOD 網站最後更新日期：Last updated 20 March 2026, 12:54PM
- MOD 版本：1.01
- MOD 檔案名稱：AuspexHelper-757-1-0-1-1773955593
- 手動維護最後下載日期：2026-05-17
- 移除原因：NoBrainer取代此功能。

### [Dog Whistle](https://www.nexusmods.com/warhammer40kdarktide/mods/539)
    狗哨 - 自動抓特感
- MOD 網站最後更新日期：Last updated 04 December 2025, 12:31AM
- MOD 版本：1.0.8
- MOD 檔案名稱：Dog Whistle 1.0.8-539-1-0-8-1764779496
- 手動維護最後下載日期：2025-12-06
- 移除原因：使用更進階的AutoMark，不用指道怪就可以標記

### [Servo-Friend](https://www.nexusmods.com/warhammer40kdarktide/mods/504)
    顱骨支援
- MOD 網站最後更新日期：Last updated 02 October 2025, 9:29PM
- MOD 版本：3.0.1
- MOD 檔案名稱：Servo Friend-504-3-1746235485
- 手動維護最後下載日期：2025-10-03
- 移除原因：原本用於黑暗關燈地圖，現在已經被Machine God's BeaconUI取代

### [Uptime](https://www.nexusmods.com/warhammer40kdarktide/mods/573)
    觀察天賦的運作狀況
- MOD 網站最後更新日期：Last updated 30 December 2025, 10:00PM
- MOD 版本：1.3.6
- MOD 檔案名稱：uptime-573-1-3-6-1767103234
- 手動維護最後下載日期：2026-01-01
- 移除原因：作者表示無法在維護已經有人接手

### [SMOG Cleaner](https://www.nexusmods.com/warhammer40kdarktide/mods/847)
    記憶體管理
- MOD 網站最後更新日期：Last updated 01 July 2026, 4:29PM
- MOD 版本：1.1
- MOD 檔案名稱：SMOG 847 1.1 cwrBAw1N3
- 手動維護最後下載日期：2026-07-06
- 移除原因：原作者已經被Nexus Mods所BAN
