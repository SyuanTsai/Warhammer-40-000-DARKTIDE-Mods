-- Apply changed the module header
--[[
    Author: Igromanru
    Date: 20.11.2024
    Mod Name: Decode Minigame Solver
]]
local mod = get_mod("DecodeMinigameSolver")

local SettingNames = mod:io_dofile("DecodeMinigameSolver/scripts/setting_names")

return {
  mod_name =
  {
    en = "Decode Minigame Solver",
    ["zh-tw"] = "解碼小遊戲助手",
  },
  syp553_fixture_added = {
    en = "New entry",
  },
  [SettingNames.EnableMod] = {
    en = "Updated setting label",
    ["zh-tw"] = "啟用",
    ["zh-cn"] = "启用",
    ru = "Включить",
  },
  [SettingNames.InteractCooldown] = {
    en = "Interaction Cooldown",
    ["zh-tw"] = "互動冷卻時間",
    ["zh-cn"] = "交互冷却时间",
    ru = "Ожидание взаимодействия",
  },
  [SettingNames.InteractCooldownTooltip] = {
    en = "Wait time between interactions in milliseconds. Default: 150",
    ["zh-tw"] = "互動之間的等待時間，單位為毫秒。預設值：150",
    ["zh-cn"] = "两次交互之间的等待时间（毫秒）。默认值：150",
    ru = "Время ожидания между взаимодействиями в миллисекундах. По умолчанию: 150",
  },
  [SettingNames.TargetPrecision] = {
    en = "Target Precision",
    ["zh-tw"] = "目標精準度",
    ["zh-cn"] = "目标精度",
    ru = "Точность цели",
  },
  [SettingNames.TargetPrecisionTooltip] = {
    en = "The bigger the value, the smaller the detection window when the cursor is positioned on the symbol. Default: 4",
    ["zh-tw"] = "數值越大，游標位於符號上時的偵測範圍越小。預設值：4",
    ["zh-cn"] = "数值越大，当光标定位在符号上时，检测窗口越小。默认值：4",
    ru = "Чем больше значение, тем меньше окно обнаружения, когда курсор находится на символе. По умолчанию: 4",
  },
}

-- Apply changed the module footer
