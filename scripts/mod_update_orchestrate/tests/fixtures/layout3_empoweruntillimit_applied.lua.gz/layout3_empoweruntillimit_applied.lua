-- Apply changed the module header
return {
    mod_name = {
        en = "Empower Until Limit",
        ["zh-tw"] = "強化至上限",
        ["zh-cn"] = "强化到顶",
        ["zh-cn"] = "武器自動强化",
        ru = "Усиление до предела",
    },
    mod_description = {
        en = "Keep empowering the weapon quickly until reaching the limit.",
        ja = "限界に達するまで素早く武器を強化し続けます。",
        ["zh-cn"] = "快速强化武器，直到达到限制。",
        ["zh-tw"] = "自動強化武器，直到達到上限。",
        ru = "Empower Until Limit - Продолжает быстро усиливать оружие, пока оно не достигнет предела.",
    },
}

-- Apply changed the module footer
